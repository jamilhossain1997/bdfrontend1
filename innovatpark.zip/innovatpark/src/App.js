import Header from './Common/Header';
import Footer from './Common/Footer';
import Home from './Component/Home';
import About from './Component/About';
import CaseStudie from './Component/CaseStudie';
import QFAS from './Component/FAQS';
import Service from './Component/Service';
import Contact from './Component/Contact';
import BlogGrid from './Component/BlogGrid';
import Blogfullwidth from './Component/Blogfullwidth';
import Blogsingle from './Component/Blogsingla';
import DataInfrastructure from './Component/Owlcarousel/DataInfrastructure';
import CaseSingle from './Component/CaseSingle';
import CloudIntegration from './Component/CloudIntegration';
import { Switch, Route } from 'react-router-dom';

function App() {
  return (
    <div className="App">
        <Header/>
          <Switch>
            <Route exact path='/' component={Home}/>
            <Route path='/about' component={About} />
            <Route path='/casestudie' component={CaseStudie}/>
            <Route path='/faq' component={QFAS}/>
            <Route path='/allService' component={Service}/>
            <Route exact path='/contact' component={Contact}/>
            <Route path='/blog' component={BlogGrid}/>
            <Route path='/blogfullwidth' component={Blogfullwidth}/>
            <Route path='/blogsingle' component={Blogsingle}/>
            <Route path='/dataInfrastructure' component={DataInfrastructure}/>
            <Route path='/CaseSingle' component={CaseSingle}/>
            <Route path='/CloudIntegration ' component={CloudIntegration }/>
          </Switch>
        <Footer/>
    </div>
  );
}

export default App;
