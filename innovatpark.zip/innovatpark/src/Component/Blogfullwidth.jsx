import React from 'react';
import Owldemo6 from './Owlcarousel/Owldemo6';

const Blogfullwidth = () => {
  return (
    <>
         {/* <!-- Inner Banner Section --> */}
    <section class="inner-banner">
        <div class="banner-curve"></div>
		<div class="auto-container">
            <div class="inner">
                <div class="theme-icon"></div>
    			<div class="title-box">
                    <h1>Blog News</h1>
                    <div class="d-text">Building a relationship between IT Services</div>
                </div>
            </div>
		</div>
    </section>
    {/* <!--End Banner Section --> */}

	{/* <!--News Section--> */}
    <section class="news-section blog-fullwidth">
        <div class="auto-container">
            <div class="news-posts">

                {/* <!--News Block--> */}
                <div class="news-block-three">
                    <div class="inner-box">
                        <div class="image-box">
                            <a href="blog-single.html"><img src="assect/images/resource/blog-image-10.jpg" alt="" title=""/></a>
                        </div>
                        <div class="lower-box">
                            <div class="category">IT Projects, Development</div>
                            <h3><a href="blog-single.html">Efficient & Measurable Benefits of Software</a></h3>
                            <div class="text">Dolor sit amet, consectetur adipisicing elitm sed don eiusmod tempor sed incididunt ut labore etsu dolore magna aliquatenim minim veniam quis ipsum nostrud exerpsum citation ullamco laboris nisi ut aliquip consequat. Duis aute irure dolorn reprehenderit voluptate velit.</div>
                            <div class="meta-info">
                                <ul class="clearfix">
                                    <li><a href="#">By Admin</a></li>
                                    <li><a href="#">24 June 2019</a></li>
                                    <li><a href="#">Comments: 53</a></li>
                                </ul>
                            </div>
                            <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>

                {/* <!--News Block--> */}
                <Owldemo6/>

                {/* <!--News Block--> */}
                <div class="news-block-three">
                    <div class="inner-box">
                        <div class="image-box">
                            <img src="assect/images/resource/blog-image-12.jpg" alt="" title=""/>
                            <a href="https://www.youtube.com/watch?v=Get7rqXYrbQ" class="theme-btn lightbox-image video-play-btn"><span class="fa fa-play"></span></a>
                        </div>
                        <div class="lower-box">
                            <div class="category">IT Projects, Development</div>
                            <h3><a href="blog-single.html">Vital Tips For Blockchain Products</a></h3>
                            <div class="text">Dolor sit amet, consectetur adipisicing elitm sed don eiusmod tempor sed incididunt ut labore etsu dolore magna aliquatenim minim veniam quis ipsum nostrud exerpsum citation ullamco laboris nisi ut aliquip consequat. Duis aute irure dolorn reprehenderit voluptate velit.</div>
                            <div class="meta-info">
                                <ul class="clearfix">
                                    <li><a href="#">By Admin</a></li>
                                    <li><a href="#">24 June 2019</a></li>
                                    <li><a href="#">Comments: 53</a></li>
                                </ul>
                            </div>
                            <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>

                {/* <!--News Block--> */}
                <div class="news-block-four">
                    <div class="inner-box">
                        <blockquote>
                            <div class="icon"><span class="flaticon-chat-2"></span></div>
                            <div class="txt">"Everything is designed. Few things are designed well."</div>
                            <div class="info">— Brian Reed</div>
                        </blockquote>
                    </div>
                </div>

                {/* <!--News Block--> */}
                <div class="news-block-three">
                    <div class="inner-box">
                        <div class="image-box">
                            <a href="blog-single.html"><img src="assect/images/resource/blog-image-13.jpg" alt="" title=""/></a>
                        </div>
                        <div class="lower-box">
                            <div class="category">IT Projects, Development</div>
                            <h3><a href="blog-single.html">Data Security With Multiple Busines Values</a></h3>
                            <div class="text">Dolor sit amet, consectetur adipisicing elitm sed don eiusmod tempor sed incididunt ut labore etsu dolore magna aliquatenim minim veniam quis ipsum nostrud exerpsum citation ullamco laboris nisi ut aliquip consequat. Duis aute irure dolorn reprehenderit voluptate velit.</div>
                            <div class="meta-info">
                                <ul class="clearfix">
                                    <li><a href="#">By Admin</a></li>
                                    <li><a href="#">24 June 2019</a></li>
                                    <li><a href="#">Comments: 53</a></li>
                                </ul>
                            </div>
                            <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>

            </div>

            {/* <!--Pagination--> */}
            <div class="pagination-box">
                <ul class="styled-pagination">
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#" class="next"><span class="fa fa-arrow-right"></span></a></li>
                </ul>
            </div>

        </div>
    </section>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>
    </>
  )
}

export default Blogfullwidth