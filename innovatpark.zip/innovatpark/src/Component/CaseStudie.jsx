import React from 'react'

const CaseStudie = () => {
  return (
    <>
       {/* <!--Search Popup--> */}
    <div id="search-popup" class="search-popup">
        <div class="close-search theme-btn"><span class="flaticon-targeting-cross"></span></div>
        <div class="popup-inner">
            <div class="overlay-layer"></div>
            <div class="search-form">
                <form method="post" action="https://t.commonsupport.xyz/zentec/index.html">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required />
                            <input type="submit" value="Search Now!" class="theme-btn"/>
                        </fieldset>
                    </div>
                </form>
                
                <br/>
                <h3>Recent Search Keywords</h3>
                <ul class="recent-searches">
                    <li><a href="#">Finance</a></li>
                    <li><a href="#">Idea</a></li>
                    <li><a href="#">Service</a></li>
                    <li><a href="#">Growth</a></li>
                    <li><a href="#">Plan</a></li>
                </ul>
            
            </div>
            
        </div>
    </div>


    {/* <!-- Inner Banner Section --> */}
    <section class="inner-banner">
        <div class="banner-curve"></div>
		<div class="auto-container">
            <div class="inner">
                <div class="theme-icon"></div>
    			<div class="title-box">
                    <h1>Case Studies</h1>
                    <div class="d-text">Building a relationship between IT Services</div>
                </div>
            </div>
		</div>
    </section>
    {/* <!--End Banner Section --> */}

	{/* <!--Cases Section Two--> */}
    <section class="cases-section-two cases-page">

        <div class="auto-container">

            <div class="sec-title centered">
                <div class="upper-text">IT Related CaseStudies & Works</div>
                <h2><strong>Featured Case Study</strong></h2>
            </div>

            {/* <!--Case Block--> */}
            <div class="case-block-two wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                <div class="inner-box clearfix">
                    <div class="image-column">
                        <div class="image-layer" style={{backgroundImage: `url(assect/images/resource/case-image-3.jpg)`}}></div>
                        <figure class="image-box">
                            <img src="assect/images/resource/case-image-3.jpg" alt="" title=""/>
                        </figure>
                        <a class="link-layer" href="case-single.html"></a>
                    </div>
                    <div class="content-column">
                        <div class="content-box">
                            <div class="title-box">
                                <h3><a href="case-single.html">Data Machine Learning</a></h3>
                                <div class="sub-text">Artificial Intelligence</div>
                            </div>
                            <div class="text-content">
                                <div class="text">Eiusmod sed incididunt labore magna sed aliquatenim veniam ipsum nostrud exercit minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip consequat. Duis aute irure dolor in reprehenderit.</div>
                                <div class="link-box"><a href="case-single.html">View Case Study <span class="arrow fa fa-arrow-right"></span></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>

    {/* <!--Cases Section--> */}
    <section class="cases-section cases-page">
        <div class="auto-container">

            {/* <!--Carousel Box--> */}
            <div class="cases-box">
                <div class="row clearfix">
                    {/* <!--Case Block--> */}
                    <div class="case-block col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <figure class="image-box">
                                <a href="case-single.html"><img src="assect/images/resource/case-image-1.jpg" alt="" title=""/></a>
                            </figure>
                            <div class="content-box">
                                <div class="title-box">
                                    <h4><a href="case-single.html">Workflow Management</a></h4>
                                    <div class="sub-text">IT Networking</div>
                                </div>
                                <div class="text-content">
                                    <div class="text">Eiusmod sed incididunt labore magna sed aliquatenim veniam ipsum nostrud exercit.</div>
                                    <div class="link-box"><a href="case-single.html">View Case Study <span class="arrow fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* <!--Case Block--> */}
                    <div class="case-block col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <figure class="image-box">
                                <a href="case-single.html"><img src="assect/images/resource/case-image-2.jpg" alt="" title=""/></a>
                            </figure>
                            <div class="content-box">
                                <div class="title-box">
                                    <h4><a href="case-single.html">Data Machine Learning</a></h4>
                                    <div class="sub-text">Artificial Intelligence</div>
                                </div>
                                <div class="text-content">
                                    <div class="text">Eiusmod sed incididunt labore magna sed aliquatenim veniam ipsum nostrud exercit.</div>
                                    <div class="link-box"><a href="case-single.html">View Case Study <span class="arrow fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* <!--Case Block--> */}
                    <div class="case-block col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <figure class="image-box">
                                <a href="case-single.html"><img src="assect/images/resource/case-image-4.jpg" alt="" title=""/></a>
                            </figure>
                            <div class="content-box">
                                <div class="title-box">
                                    <h4><a href="case-single.html">Workflow Management</a></h4>
                                    <div class="sub-text">IT Networking</div>
                                </div>
                                <div class="text-content">
                                    <div class="text">Eiusmod sed incididunt labore magna sed aliquatenim veniam ipsum nostrud exercit.</div>
                                    <div class="link-box"><a href="case-single.html">View Case Study <span class="arrow fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* <!--Case Block--> */}
                    <div class="case-block col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <figure class="image-box">
                                <a href="case-single.html"><img src="assect/images/resource/case-image-5.jpg" alt="" title=""/></a>
                            </figure>
                            <div class="content-box">
                                <div class="title-box">
                                    <h4><a href="case-single.html">Data Machine Learning</a></h4>
                                    <div class="sub-text">Artificial Intelligence</div>
                                </div>
                                <div class="text-content">
                                    <div class="text">Eiusmod sed incididunt labore magna sed aliquatenim veniam ipsum nostrud exercit.</div>
                                    <div class="link-box"><a href="case-single.html">View Case Study <span class="arrow fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>

    
    <div class="theme-separator"></div>
    </>
  )
}

export default CaseStudie