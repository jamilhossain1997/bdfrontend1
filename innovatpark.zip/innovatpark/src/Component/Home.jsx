import React from 'react';
import Owlcarousel2 from './Owlcarousel/Owlcarousel2';
import Owldemo1 from './Owlcarousel/Owldemo1';
import Owldemo3 from './Owlcarousel/Owldemo3';
import axios from 'axios';
import { useState } from 'react';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
    const baseURL = "http://127.0.0.1:8000";
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [phone,setPhone]=useState('');
    const [subject,setSubject]=useState('');
    const [message,setMeg]=useState('');
    const [meg, setMessage] = useState(null);
    const [solutions,setSolutions]=useState([]);

    useEffect(()=>{
        SolutionsView();
    },[])

    function SolutionsView(){
        axios.get('/api/solutionserviceView')
        .then(function (response) {
            console.log(response);
            setSolutions(response.data);
          })
          .catch(function (error) {
            console.log(error);
          })
    }

    // console.log(solutions.data.id[1]);
    function handleClick(){
       let item={name,email,phone,subject,message}
       axios.post('/api/Clientreq',item)
       .then(function (response) {
        console.log(response);
        setMessage(response.data.message);
      })
      .catch(function (error) {
        console.log(error);
      })
    }
  return (
    <>
       {/* <!-- Banner Section --> */}
       <Owldemo1/>
    {/* <!--End Banner Section --> */}




    {/* <!--About Section--> */}
    <section class="about-section">
        <div class="auto-container">
        	<div class="row clearfix">
                {/* <!--Text Column--> */}
                <div class="text-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title">
                            <div class="upper-text">iNNOVAT PARK - Welcome to IT Solutions</div>
                            <h2>Let us be your next <strong>Preferred IT Partner</strong></h2>
                        </div>

                        <div class="text-content">
                            <p>Dolor sit amet, consectetur adipisicing elitm sed do eiusmod temp sed incididunt ut labore etsu dolore magna aliquatenim minim veniam quis ipsum nostrud exer citation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolorn reprehenderit voluptate velit esse. </p>
                            <ul class="list-style-one">
                                <li>We are committed to providing quality IT Services</li>
                                <li>Our benefits are endless for local IT Companies & Startups</li>
                                <li>Really know the true needs and expectations of customers</li>
                                <li>Talented & experienced management solutions for IT</li>
                                <li>Processes of achieving the excellence and continue improvements</li>
                            </ul>
                        </div>
                    </div>
                </div>
                {/* <!--Image Column--> */}
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        {/* <!--Images--> */}
                        <div class="images">
                            <div class="row clearfix">
                                <figure class="image col-md-6 col-sm-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms"><img src="assect/images/resource/about-image-1.jpg" alt="" title=""/></figure>
                                <figure class="image col-md-6 col-sm-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms"><img src="assect/images/resource/about-image-2.jpg" alt="" title=""/></figure>
                                <figure class="image col-md-6 col-sm-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms"><img src="assect/images/resource/about-image-3.jpg" alt="" title=""/></figure>
                                <figure class="image col-md-6 col-sm-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms"><img src="assect/images/resource/about-image-4.jpg" alt="" title=""/></figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>

    {/* <!--Services Section--> */}
    <section class="services-section">
        <div class="gradient-layer"></div>
        <div class="pattern-layer"></div>

        <div class="auto-container">
            <div class="row clearfix">
                {/* <!--Column--> */}
                <div class="column col-lg-4 col-md-12 col-sm-12">
                    <div class="sec-title wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="upper-text">ZenTec IT Services</div>
                        <h2><strong>Solutions And Focus Areas</strong></h2>
                        <div class="lower-text">Digital Transformation By IT Solutions</div>
                    </div>

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/1.png" alt="" title=""/></div>
                            </div>
                            <h3><Link to="/dataInfrastructure">Data Infrastructure</Link></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><Link to="/dataInfrastructure"><span class="fa fa-arrow-right"></span></Link></div>
                        </div>
                    </div>

                </div>

                {/* <!--Column--> */}
                <div class="column col-lg-4 col-md-12 col-sm-12">

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/2.png" alt="" title=""/></div>
                            </div>
                            <h3><Link to='/CloudIntegration'>{solutions.titleText}</Link></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><Link to='/CloudIntegration'><span class="fa fa-arrow-right"></span></Link></div>
                        </div>
                    </div>

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/3.png" alt="" title=""/></div>
                            </div>
                            <h3><Link to='/allService'>IT Startup Projects</Link></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><a to='/allService'><span class="fa fa-arrow-right"></span></a></div>
                        </div>
                    </div>

                </div>

                {/* <!--Column--> */}
                <div class="column col-lg-4 col-md-12 col-sm-12">
                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/4.png" alt="" title=""/></div>
                            </div>
                            <h3><Link to='/allService'>Product Engineering</Link></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><Link to='/allService'><span class="fa fa-arrow-right"></span></Link></div>
                        </div>
                    </div>

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/5.png" alt="" title=""/></div>
                            </div>
                            <h3><Link to='/allService'>Business Security</Link></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><Link to='/allService'><span class="fa fa-arrow-right"></span></Link></div>
                        </div>
                    </div>

                </div>

            </div>

            <div class="bottom-text">
                <div class="text">We’re ready to discover and unlock your potential. <a href="services.html"><strong>Get The Solutions</strong></a> or Call us Today! <a href="tel:258-000-3694"><strong>258-000-3694</strong></a></div>
            </div>

        </div>
    </section>



    {/* <!--Cases Section Two--> */}
   <Owlcarousel2/>

    {/* <!--Team Section--> */}
    <section class="team-section">
        <div class="pattern-layer"></div>

        <div class="auto-container">
            <div class="row clearfix">
                {/* <!--Column--> */}
                <div class="column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title">
                            <div class="upper-text">Ambitious & Dedicated Team</div>
                            <h2>iNNOVAT PARK <strong>IT Experts</strong></h2>
                        </div>
                        <div class="text-content">
                            <div class="text">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet velit sed quia non numquam eius modi tempora incidunt labore dolore magna aliqua enim minim veniam, quis nostrud exercitation ullamco.</div>
                        </div>

                        <div class="team-block wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="about.html"><img src="assect/images/resource/team-image-1.jpg" alt=""/></a>
                                </div>
                                <div class="title-box">
                                    <h3 class="name"><a href="about.html">Ashiful Islam</a></h3>
                                    <div class="designation">Chief Technology Officer (CTO)  </div>
                                </div>
                                <div class="text">Veniam quis nostrud exercitaon ullam laboris nis aliquip sed conseqal.</div>
                            </div>
                        </div>

                    </div>
                </div>

                {/* <!--Column--> */}
                <div class="column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">

                        <div class="team-block wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="about.html"><img src="assect/images/resource/team-image-2.jpg" alt=""/></a>
                                </div>
                                <div class="title-box">
                                    <h3 class="name"><a href="about.html">Nokibul Hassan</a></h3>
                                    <div class="designation">Managing Director</div>
                                </div>
                                <div class="text">Veniam quis nostrud exercitaon ullam laboris nis aliquip sed conseqal.</div>
                            </div>
                        </div>

                        <div class="team-block wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="about.html"><img src="assect/images/resource/team-image-3.jpg" alt=""/></a>
                                </div>
                                <div class="title-box">
                                    <h3 class="name"><a href="about.html">Abir Shykat</a></h3>
                                    <div class="designation">Chief Executive Officer (CEO)</div>
                                </div>
                                <div class="text">Veniam quis nostrud exercitaon ullam laboris nis aliquip sed conseqal.</div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

            <div class="view-all link-box">
                <a href="#" class="theme-btn btn-style-one"><div class="btn-title">View Full Team</div></a>
            </div>

        </div>
    </section>
 
    {/* <!--Testimonials Section--> */}
    <Owldemo3/>
 

    {/* <!--Contact Section--> */}
    <section class="contact-section">
        <div class="map-pattern-layer"></div>

        <div class="auto-container">
            <div class="row clearfix">
                {/* <!--Text Column--> */}
                <div class="text-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title">
                            <div class="upper-text">Get In Touch With Us Today!</div>
                            <h2><strong>Need Our Services? <br/>Book Your Appointment</strong></h2>
                            <div class="lower-text">We Help Customers Digital Transformation By IT Solutions</div>
                        </div>

                        <ul class="info">
                            <li><div class="phone-title">call us for support</div></li>
                            <li class="phone"><a href="tel:(+88) 01771-858483"><span class="icon sl-icon-call-in"></span> <strong>(+88) 01771-858483</strong></a></li>
                            <li class="email"><a href="mailto:support@innovatpark.com">support@innovatpark.com</a></li>
                        </ul>
                    </div>
                </div>
                {/* <!--Form Column--> */}
                <div class="form-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        {/* <!--Form Box--> */}
                        <div class="form-box">
                            <div class="default-form appointment-form">

                               {meg && <div class="alert alert-secondary" role="alert">
                                                {meg}
                                 </div>}

                                    <div class="row clearfix">                                    
                                       <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="text"  value={name} onChange={(e) => setName(e.target.value)} placeholder="Your Name" required/>
                                        </div>
                                        
                                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="email"  value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required/>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="text"  value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" required/>
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <select class="custom-select-box"  value={subject} onChange={(e) => setSubject(e.target.value)}>
                                                <option>Inquiry About</option>
                                                <option>IT Cloud Integration</option>
                                                <option>Business Security</option>
                                                <option>Product Engineering</option>
                                            </select>
                                        </div>

                                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                            <textarea  value={message} onChange={(e) => setMeg(e.target.value)} placeholder="Message" required></textarea>
                                        </div>
                
                                        <div class="form-group col-md-12 col-sm-12">
                                            <button type="submit" onClick={handleClick} class="theme-btn btn-style-one"><span class="btn-title">Make a Request</span></button>
                                        </div>
                                    </div>
                                
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    </>
  )
}

export default Home