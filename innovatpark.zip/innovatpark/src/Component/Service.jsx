import React from 'react';
import Owldemo4 from './Owlcarousel/Owldemo4';
import Owldemo5 from './Owlcarousel/Owldemo5';
import axios from 'axios';
import { useState } from 'react';
import { useEffect } from 'react';
import {Link} from 'react-router-dom';

const Service = () => {
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [phone,setPhone]=useState('');
    const [subject,setSubject]=useState('');
    const [message,setMeg]=useState('');
    const [meg, setMessage] = useState(null);

    function handleClick(){
        let item={name,email,phone,subject,message}
        axios.post('/api/Clientreq',item)
        .then(function (response) {
         console.log(response);
         setMessage(response.data.message);
       })
       .catch(function (error) {
         console.log(error);
       })
     }
  return (
    <>
      
    {/* <!-- Inner Banner Section --> */}
    <section class="inner-banner alternate">
        <div class="image-layer" style={{backgroundImage: `url(images/background/banner-bg-1.jpg)`}}></div>
		<div class="auto-container">
            <div class="inner">
    			<div class="title-box">
                    <h1>Services We Offer</h1>
                    <div class="d-text">Building a relationship between IT Services</div>
                </div>
            </div>
		</div>
    </section>
    {/* <!--End Banner Section --> */}

	{/* <!--Services Section--> */}
    <section class="services-section">
        <div class="gradient-layer"></div>

        <div class="auto-container">
            <div class="row clearfix">
                {/* <!--Column--> */}
                <div class="column col-lg-4 col-md-12 col-sm-12">
                    <div class="sec-title wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="upper-text">ZenTec IT Services</div>
                        <h2><strong>Solutions And Focus Areas</strong></h2>
                        <div class="lower-text">Digital Transformation By IT Solutions</div>
                    </div>

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/1.png" alt="" title=""/></div>
                            </div>
                            <h3><a href="data-infrastructure.html">Data Infrastructure</a></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><Link to='/dataInfrastructure'><span class="fa fa-arrow-right"></span></Link></div>
                        </div>
                    </div>

                </div>

                {/* <!--Column--> */}
                <div class="column col-lg-4 col-md-12 col-sm-12">

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/2.png" alt="" title=""/></div>
                            </div>
                            <h3><a href="cloud-integration.html">IT Cloud Integration</a></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><Link Link to='/allService'><span class="fa fa-arrow-right"></span></Link></div>
                        </div>
                    </div>

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/3.png" alt="" title=""/></div>
                            </div>
                            <h3><a href="it-startup.html">IT Startup Projects</a></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><a href="it-startup.html"><span class="fa fa-arrow-right"></span></a></div>
                        </div>
                    </div>

                </div>

                {/* <!--Column--> */}
                <div class="column col-lg-4 col-md-12 col-sm-12">
                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/4.png" alt="" title=""/></div>
                            </div>
                            <h3><a href="product-engineering.html">Product Engineering</a></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><Link Link to='/allService'><span class="fa fa-arrow-right"></span></Link></div>
                        </div>
                    </div>

                    {/* <!--Service Block--> */}
                    <div class="service-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><img src="assect/images/icons/services/5.png" alt="" title=""/></div>
                            </div>
                            <h3><a href="business-security.html">Business Security</a></h3>
                            <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco</div>
                            <div class="more-link"><a href="business-security.html"><span class="fa fa-arrow-right"></span></a></div>
                        </div>
                    </div>

                </div>

            </div>

            <div class="bottom-text">
                <div class="text">We’re ready to discover and unlock your potential. <Link to='/allService'><strong>Get The Solutions</strong></Link> or Call us Today! <a href="tel:258-000-3694"><strong>258-000-3694</strong></a></div>
            </div>

        </div>
    </section>

    {/* <!--Video Section--> */}
    <section class="video-section alternate">
        <div class="image-layer" style={{backgroundImage: `url(assect/images/background/image-3.jpg)`}}></div>
        <div class="auto-container">
            <div class="video-link">
                <a href="https://www.youtube.com/watch?v=Get7rqXYrbQ" class="theme-btn lightbox-image"><span class="flaticon-play-button"></span></a>
            </div>
            <h2>ZenTec IT Solutions will get you on the move towards your goals.</h2>
        </div>
    </section>

    {/* <!--Services Section--> */}
    <section class="services-section-three">

        <div class="auto-container">
            <div class="sec-title centered">
                <div class="upper-text">IT Related CaseStudies & Works</div>
                <h2><strong>Prominent IT Solutions</strong></h2>
            </div>
            <div class="services-box">
                <div class="row clearfix">
                    {/* <!--Service Block--> */}
                    <div class="service-block-four col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><span class="themify-crown"></span></div>
                            </div>
                            <h3><a href="services.html">Pure Agile Methodology</a></h3>
                            <div class="text">Culpa qui officia deserunt molit animid est laborum perspiciatis unde omnis iste natus accusantium dolore.</div>
                        </div>
                    </div>
                    {/* <!--Service Block--> */}
                    <div class="service-block-four col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><span class="themify-bar-chart-alt"></span></div>
                            </div>
                            <h3><a href="services.html">Passionate About Success</a></h3>
                            <div class="text">Culpa qui officia deserunt molit animid est laborum perspiciatis unde omnis iste natus accusantium dolore.</div>
                        </div>
                    </div>
                    {/* <!--Service Block--> */}
                    <div class="service-block-four col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><span class="themify-settings"></span></div>
                            </div>
                            <h3><a href="services.html">Global Technology Services</a></h3>
                            <div class="text">Culpa qui officia deserunt molit animid est laborum perspiciatis unde omnis iste natus accusantium dolore.</div>
                        </div>
                    </div>
                    {/* <!--Service Block--> */}
                    <div class="service-block-four col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><span class="themify-flag-alt"></span></div>
                            </div>
                            <h3><Link to='/allService'>Solve Customer’s IT Problems</Link></h3>
                            <div class="text">Culpa qui officia deserunt molit animid est laborum perspiciatis unde omnis iste natus accusantium dolore.</div>
                        </div>
                    </div>
                    {/* <!--Service Block--> */}
                    <div class="service-block-four col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><span class="themify-world"></span></div>
                            </div>
                            <h3><Link to='/allService'>Work With Many Partners </Link></h3>
                            <div class="text">Culpa qui officia deserunt molit animid est laborum perspiciatis unde omnis iste natus accusantium dolore.</div>
                        </div>
                    </div>
                    {/* <!--Service Block--> */}
                    <div class="service-block-four col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon-outer">
                                <span class="icon-bg"></span>
                                <div class="icon-box"><span class="themify-panel"></span></div>
                            </div>
                            <h3><Link to='/allService'>Core Values and Missions</Link></h3>
                            <div class="text">Culpa qui officia deserunt molit animid est laborum perspiciatis unde omnis iste natus accusantium dolore.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>

    {/* <!--Cases Section--> */}
    <section class="cases-section">
        {/* <div class="gradient-layer"></div> */}

        <div class="auto-container">

            <div class="sec-title centered">
                <div class="upper-text">Our Case Studies</div>
                <h2><strong>IT Solutions & Projects</strong></h2>
                <div class="lower-text">Sit amet consectetur adipisicing elitm sed eiusmod temp sed incididunt labore dolore magna aliquatenim veniam quis ipsum nostrud exer citation ullamco laboris.</div>
            </div>

            {/* <!--Carousel Box--> */}
            
                <Owldemo4/>
            
            {/* <!--End Carousel Box--> */}

            <div class="bottom-text">
                <div class="text">We’re ready to discover and unlock your potential. <strong>Call us Today!</strong> &nbsp;<a href="tel:258-000-3694"><strong>258-000-3694</strong></a></div>
            </div>

        </div>
    </section>

    {/* <!--Testimonials Section--> */}
    <section class="testimonials-two">
        <div class="image-layer" style={{backgroundImage: `url(images/background/image-2.jpg)`}}></div>

        <div class="auto-container">
            <div class="sec-title centered">
                <div class="upper-text">Read The Testimonials</div>
                <h2>What Clients Says <strong>About Us</strong></h2>
                <div class="lower-text">Sit amet consectetur adipisicing elitm sed eiusmod temp sed incididunt labore dolore magna aliquatenim veniam quis ipsum nostrud exer citation ullamco laboris.</div>
            </div>

            <div class="carousel-box">
               <Owldemo5/>
            </div>
        </div>

    </section>

    {/* <!--Contact Section--> */}
    <section class="contact-section">
        <div class="map-pattern-layer"></div>

        <div class="auto-container">
            <div class="row clearfix">
                {/* <!--Text Column--> */}
                <div class="text-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title">
                            <div class="upper-text">Get In Touch With Us Today!</div>
                            <h2><strong>Need Our Services? <br/>Book Your Appointment</strong></h2>
                            <div class="lower-text">We Help Customers Digital Transformation By IT Solutions</div>
                        </div>

                        <ul class="info">
                            <li><div class="phone-title">call us for support</div></li>
                            <li class="phone"><a href="tel:(+1)500.369.2580"><span class="icon sl-icon-call-in"></span> <strong>(+1) 500.369.2580</strong></a></li>
                            <li class="email"><a href="mailto:support@zentec.com">support@zentec.com</a></li>
                        </ul>
                    </div>
                </div>
                {/* <!--Form Column--> */}
                  {/* <!--Form Column--> */}
                  <div class="form-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        {/* <!--Form Box--> */}
                        <div class="form-box">
                            <div class="default-form appointment-form">

                               {meg && <div class="alert alert-secondary" role="alert">
                                                {meg}
                                 </div>}

                                    <div class="row clearfix">                                    
                                       <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="text"  value={name} onChange={(e) => setName(e.target.value)} placeholder="Your Name" required/>
                                        </div>
                                        
                                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="email"  value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required/>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="text"  value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" required/>
                                        </div>

                                        <div class="form-group col-md-6 col-sm-12">
                                            <select class="custom-select-box"  value={subject} onChange={(e) => setSubject(e.target.value)}>
                                                <option>Inquiry About</option>
                                                <option>IT Cloud Integration</option>
                                                <option>Business Security</option>
                                                <option>Product Engineering</option>
                                            </select>
                                        </div>

                                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                            <textarea  value={message} onChange={(e) => setMeg(e.target.value)} placeholder="Message" required></textarea>
                                        </div>
                
                                        <div class="form-group col-md-12 col-sm-12">
                                            <button type="submit" onClick={handleClick} class="theme-btn btn-style-one"><span class="btn-title">Make a Request</span></button>
                                        </div>
                                    </div>
                                
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    </>
  )
}

export default Service