import React from 'react'
import { Link } from 'react-router-dom'

const CloudIntegration = () => {
  return (
     <>
         {/* <!-- Inner Banner Section --> */}
    <section class="inner-banner alternate">
        <div class="image-layer" style={{backgroundImage: `url(assect/images/background/banner-bg-1.jpg)`}}></div>
        <div class="auto-container">
            <div class="inner">
                <div class="title-box">
                    <h1>Cloud Integration</h1>
                    <div class="d-text">Building a relationship between IT Services</div>
                </div>
            </div>
        </div>
    </section>
    {/* <!--End Banner Section --> */}

	<div class="sidebar-page-container services-page">
        <div class="auto-container">
            <div class="row clearfix">
                
                {/* <!--Content Side--> */}
                <div class="content-side col-lg-8 col-md-12 col-sm-12">
                    <div class="services-content">
                        <div class="service-details">
                            <div class="image-box">
                                <img src="assect/images/resource/service-single-image.jpg" alt=""/>
                            </div>
                            {/* <!--content--> */}
                            <div class="content">
                                <h3>Cloud Integration</h3>
                                <div class="text">
                                    <p>The ship set ground on the shore that this group would somehow form a family that's the way the Love Boat promis something for everyone that this group would somehow form a family that's the way we all became the brady bunch  that this group a family that's the way the Love Boat promises something for everyone that this group would some is how form a family that's the way we all became the brady bunch that this group.</p>
                                    <p>This group would somehow form a family that's the way we all became the brady bunch that this group a family of a that's the way the Love Boat promises something for everyone that this group would some is how form a family mas that's the way we all became the brady bunch that this group.</p>
                                    <p>The old somehow form a family that's the way the Love Boat promis something for everyone that this group would somehow form a family that's the way we all became the brady bunch  that this group a family that's the way the Love Boat promises something for everyone that this group would some is how form a family that's the way we all became the brady bunch that this group.</p>
                                </div>
                                {/* <!--Two Column--> */}
                                <div class="two-col">
                                    <div class="row clearfix">
                                        <div class="column col-lg-6 col-md-6 col-sm-12">
                                            <div class="image"><img src="assect/images/resource/featured-image-4.jpg" alt=""/></div>
                                        </div>
                                        <div class="column col-lg-6 col-md-6 col-sm-12">
                                            <div class="image"><img src="assect/images/resource/featured-image-5.jpg" alt=""/></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text">
                                    <p>The old somehow form a family that's the way the Love Boat promis something for everyone that this group would somehow form a family that's the way we all became the brady bunch  that this group a family that's the way the Love Boat promises something for everyone that this group would some is how form a family that's the way we all became the brady bunch that this group.</p>

                                    <ul class="list-style-one">
                                        <li>The old somehow form a family that's the way the Love Boat promis something for everyone that this group would somehow form.</li>
                                        <li>The Love Boat promis someg for everyone. </li>
                                        <li>The old somehow form a family that's the way the Love Boat promis something for everyone that this group would somehow form.</li>
                                        <li>Boat promises something for everyone that this groupfor everyone that this group.</li>
                                        <li>The old somehow form a family that's the way the Love Boat promis something for everyone that this group would somehow form.</li>
                                        <li>The old somehow form a family that's the way to morries.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* <!--Sidebar Side--> */}
                <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                    <aside class="sidebar services-sidebar">
                        {/* <!--Services Widget--> */}
                        <div class="sidebar-widget services-widget">
                            <div class="widget-inner">
                                <ul>
                                    <li><Link to="/dataInfrastructure">Data Infrastructure</Link></li>
                                    <li class="active"><Link to="/CloudIntegration">IT Cloud Integration</Link></li>
                                    <li><Link to="/blog">IT Startup Projects</Link></li>
                                </ul>
                            </div>
                        </div>
                        {/* <!--Downloads Widget--> */}
                        <div class="sidebar-widget downloads-widget">
                            <div class="sidebar-title">
                                <h3>Related Downloads</h3>
                            </div>
                            <div class="widget-inner">
                                <ul>
                                    <li><a href="#"><span class="far fa-file-pdf"></span> Presentation PDF</a></li>
                                    <li><a href="#"><span class="far fa-file-pdf"></span> Brochure Guide</a></li>
                                    <li><a href="#"><span class="far fa-file-pdf"></span> our Service Areas</a></li>
                                </ul>
                            </div>
                        </div>
                        {/* <!--Info Widget--> */}
                        <div class="sidebar-widget info-widget">
                            <div class="widget-inner">
                                <div class="image"><a href="#"><img src="assect/images/resource/featured-image-4.jpg" alt=""/></a></div>
                                <div class="lower">
                                    <div class="subtitle">Got any Questions? <br/>Call us Today!</div>
                                    <div class="icon-box"><span class="flaticon-telephone"></span></div>
                                    <div class="phone"><a href="tel:(+1)-500.369.2580">(+1) 500.369.2580</a></div>
                                    <div class="email"><a href="mailto:support@zentec.net">support@zentec.net</a></div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
                
            </div>
        </div>
    </div>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>
     </>
  )
}

export default CloudIntegration