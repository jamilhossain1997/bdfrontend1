import React,{useState,useEffect} from 'react'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import axios from 'axios';
const Owldemo3 = () => {

    const options={loop: true, margin: 0, autoheight:true, lazyload:true, nav: true, dots: true, autoplay: true, autoplayTimeout: 5000, smartSpeed: 500, responsive:{ 0 :{ items: 1 }, 768 :{ items : 1 } , 1024:{ items : 1 }}}
    const [data,setData]=useState([]);

    useEffect(()=>{
       axios.get('/api/testimonialsSectionView')
       .then(function (response) {
        console.log(response);
        setData(response.data);
        })
        .catch(function (error) {
            console.log(error);
        })
        },[])
  return (
    <>
        
       <section class="testimonials-section">
        <div class="image-layer" style={{backgroundImage: `url(assect/images/background/image-2.jpg)`}}></div>

        <div class="auto-container">
            <div class="carousel-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                <OwlCarousel class="testimonial-carousel theme-carousel owl-theme owl-carousel" {...options}>
                    {/* <!--Slide--> */}
                    {
                        data.map((items)=>
                        <div class="slide-item">
                        <div class="inner">
                            <div class="icon-box"><span class="flaticon-chat-2"></span></div>
                            <div class="title">{items.text}</div>
                            <div class="text">{items.subtext}</div>
                            <div class="info">
                                <div class="name">{items.name}</div>
                                <div class="designation">{items.designation}</div>
                            </div>
                        </div>
                    </div>
                        )
                    }
                   
                   
                </OwlCarousel>
            </div>
        </div>
    </section>
       
    </>
  )
}

export default Owldemo3