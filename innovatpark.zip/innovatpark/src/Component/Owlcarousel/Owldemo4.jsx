import React, { useState, useEffect } from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Owldemo4 = () => {

    const options = { loop: true, margin: 40, autoheight: true, lazyload: true, nav: true, dots: false, autoplay: true, autoplayTimeout: 7000, smartSpeed: 700, responsive: { 0: { items: 1 }, 991: { items: 1 }, 992: { items: 2 }, 1024: { items: 2 } } }
    const baseURL = "http://127.0.0.1:8000/";
    const [data, setData] = useState([]);
    useEffect(() => {
        axios.get('/api/ourCaseStudiesView')
            .then(function (response) {
                console.log(response);
                setData(response.data);
            })
            .catch(function (error) {
                console.log(error);
            })
    }, [])

    return (
        <>
            <div class="page-wrapper">

                <div class="carousel-box">
                    <OwlCarousel class="cases-carousel theme-carousel owl-theme owl-carousel" {...options} >
                        {/* <!-- Slide Item --> */}
                        {
                            data.map((items) =>
                             
                                <div class="slide-item">
                                    <div class="case-block">
                                        <div class="inner-box">
                                            <figure class="image-box">
                                                <Link to="/casestudie"><img src={`${baseURL}`+ items.image} alt="tutul_img" title="" /></Link>
                                            </figure>
                                            <div class="content-box">
                                                <div class="title-box">
                                                    <h4><Link to="/casestudie">{items.text}</Link></h4>
                                                    <div class="sub-text">{items.subtext}</div>
                                                </div>
                                                <div class="text-content">
                                                    <div class="text">{items.textarea}</div>
                                                    <div class="link-box"><Link to="/casestudie">View Case Study <span class="arrow fa fa-arrow-right"></span></Link></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        }
                    </OwlCarousel>
                </div>

            </div>
        </>
    )
}

export default Owldemo4