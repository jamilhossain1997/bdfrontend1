import React from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import axios from 'axios';
import { useState } from 'react';
import { useEffect } from 'react';

const Owldemo5 = () => {
    const baseURL = "http://127.0.0.1:8000/";
    const [data,setData]=useState([]);

    useEffect(()=>{
        Test();
    },[])

    function Test(){
        axios.get("/api/readTheTestimonialsView")
        .then((res)=>{
            console.log(res);
            setData(res.data);
        })
        .catch((err)=>{
            console.log(err);
        })
    }
  return (
    <>
        <OwlCarousel class="testimonial-carousel theme-carousel owl-theme owl-carousel" items={3} autoplay={true} margin={30} autoheight={true} lazyload={true} nav={true} dots={true} autoplayTimeout={7000} smartSpeed={700}>
                   
                    {
                        data.map((item)=>
                        <div class="testimonial-block">
                        <div class="inner">
                            <div class="content-box">
                                <div class="content">
                                    <div class="text">{item.textarea}</div>
                                </div>
                            </div>
                            
                            <div class="info">
                                <div class="image"><img src={`${baseURL}`+ item.image} alt="tutul_img"/></div>
                                <div class="name">{item.text}</div>
                                <div class="designation">{item.subtext}</div>
                                <div class="rating"><span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span></div>
                            </div>
                        </div>
                    </div>
                        )
                    }
                   
                   

                </OwlCarousel>
            
    </>
  )
}

export default Owldemo5