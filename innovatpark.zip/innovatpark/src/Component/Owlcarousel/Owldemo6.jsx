import React from 'react'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
const Owldemo6 = () => {
    return (
        <>
            <div class="news-block-three">
                <div class="inner-box">
                    <div class="image-box">
                        <OwlCarousel class="news-image-carousel theme-carousel owl-theme owl-carousel" items={3} autoplay={true} margin={30} autoheight={true} lazyload={true} nav={true} dots={true} autoplayTimeout={7000} smartSpeed={700}  >
                            {/* <!-- Slide Item --> */}
                            <div class="slide-item">
                                <a href="blog-single.html"><img src="assect/images/resource/blog-image-11.jpg" alt="" title="" /></a>
                            </div>
                            {/* <!-- Slide Item --> */}
                            <div class="slide-item">
                                <a href="blog-single.html"><img src="assect/images/resource/blog-image-12.jpg" alt="" title="" /></a>
                            </div>
                            {/* <!-- Slide Item --> */}
                            <div class="slide-item">
                                <a href="blog-single.html"><img src="assect/images/resource/blog-image-13.jpg" alt="" title="" /></a>
                            </div>
                        </OwlCarousel>
                    </div>
                    <div class="lower-box">
                        <div class="category">IT Projects, Development</div>
                        <h3><a href="blog-single.html">Native or Cross-Platform: Mobile Apps</a></h3>
                        <div class="text">Dolor sit amet, consectetur adipisicing elitm sed don eiusmod tempor sed incididunt ut labore etsu dolore magna aliquatenim minim veniam quis ipsum nostrud exerpsum citation ullamco laboris nisi ut aliquip consequat. Duis aute irure dolorn reprehenderit voluptate velit.</div>
                        <div class="meta-info">
                            <ul class="clearfix">
                                <li><a href="#">By Admin</a></li>
                                <li><a href="#">24 June 2019</a></li>
                                <li><a href="#">Comments: 53</a></li>
                            </ul>
                        </div>
                        <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Owldemo6