import React from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import axios from 'axios';
import { useState } from 'react';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';

const Owlcarousel2 = () => {
    const options = { loop: true, margin: 30, autoheight: true, lazyload: true, nav: true, dots: true, autoplay: true, autoplayTimeout: 7000, smartSpeed: 700, responsive: { 0: { items: 1 }, 800: { items: 1 }, 991: { items: 1 }, 1024: { items: 1 } } }
    const logooptions={loop: true, margin: 30, autoheight:true, lazyload:true, nav: true, dots: true, autoplay: true, autoplayTimeout: 6000, smartSpeed: 500, responsive:{ 0 :{ items: 1 }, 600 :{ items : 2 }, 768 :{ items : 3 } , 800:{ items : 3 }, 1024:{ items : 4 }, 1200:{ items : 5 }}}
    const baseURL = "http://127.0.0.1:8000/";
    const [data, setData] = useState([]);
    const [logo,setLogo]=useState([]);
    useEffect(() => {
        axios.get('/api/solutionprojectView')
            .then(function (response) {
                console.log(response);
                setData(response.data);
            })
            .catch(function (error) {
                console.log(error);
            })
    }, [])
    useEffect(() => {
        axios.get('/api/SponsorsLogoView')
            .then(function (response) {
                console.log(response);
                setLogo(response.data);
            })
            .catch(function (error) {
                console.log(error);
            })
    }, [])
    return (
        <>
           
                <section class="cases-section-two">
                    <div class="gradient-layer"></div>

                    <div class="auto-container">

                        <div class="sec-title centered">
                            <div class="upper-text">IT Related CaseStudies & Works</div>
                            <h2><strong>IT Solutions & Projects</strong></h2>
                        </div>

                        {/* <!--Carousel Box--> */}
                        <div class="carousel-box">
                            <OwlCarousel class="cases-carousel-two  owl-theme owl-carousel" {...options}>
                                {/* <!-- Slide Item --> */}
                                {
                                    data.map((items) =>
                                        <div class="slide-item">
                                            {/* <!--Case Block--> */}
                                            <div class="case-block-two">
                                                <div class="inner-box clearfix">
                                                    <div class="image-column">
                                                        <div class="image-layer" ><img src={`${baseURL}`+items.image} alt='img-tutul'style={{height:`400px`}}/></div>
                                                        <figure class="image-box">
                                                        <img src={`${baseURL}`+items.image} alt='img-tutul'style={{height:`400px`}}/>
                                                        </figure>
                                                        <Link class="link-layer" to='/blogsingle'></Link>
                                                    </div>
                                                    <div class="content-column">
                                                        <div class="content-box">
                                                            <div class="title-box">
                                                                <h3><Link  to='/blogsingle'>{items.text}</Link></h3>
                                                                <div class="sub-text">{items.subtext}</div>
                                                            </div>
                                                            <div class="text-content">
                                                                <div class="text">{items.textarea}</div>
                                                                <div class="link-box"><Link  to='/blogsingle'>View Case Study <span class="arrow fa fa-arrow-right"></span></Link></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                }

                            </OwlCarousel>
                        </div>
                        {/* <!--End Carousel Box--> */}

                    </div>

                    <div class="sponsors-outer">
                        {/* <!--Sponsors--> */}
                        <div class="auto-container">
                            {/* <!--Sponsors Carousel--> */}
                            <OwlCarousel class="sponsors-carousel theme-carousel owl-theme owl-carousel" {...logooptions}>
                                {
                                    logo.map((items)=>
                                        <div class="slide-item"><figure class="image-box"><a href="#"><img src={`${baseURL}`+items.image} alt="" /></a></figure></div>
                                    )
                                }
                            </OwlCarousel>
                        </div>
                    </div>
                </section>
         
        </>
    )
}

export default Owlcarousel2