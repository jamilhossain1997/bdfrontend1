import React from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';

const Owldemo1 = () => {
    const options={loop: true, margin: 0, autoheight:true, lazyload:true, nav: true, dots: true, autoplay: true, autoplayTimeout: 6000, smartSpeed: 300, responsive:{ 0 :{ items: 1 }, 768 :{ items : 1 } , 1000:{ items : 1 }}}
    
    return (
        <>
           
                <section class="banner-section banner-two">
                    <OwlCarousel  class="banner-carousel theme-carousel owl-theme owl-carousel" {...options} >
                        <div class="slide-item">
                            <div class="image-layer" style={{ backgroundImage: "url('assect/images/main-slider/1.jpg')" }}></div>
                            <div class="auto-container">
                                <div class="content-box">
                                    <div class="content">
                                        <div class="inner">
                                            <div class="sub-title">IT Solutions For Easy Integration</div>
                                            <h1><strong>Innovative and Productive</strong></h1>
                                            <div class="text">Building a relationship between IT companies & experts</div>
                                            <div class="links-box">
                                                <a href="about.html" class="theme-btn btn-style-one"><div class="btn-title">More Details</div></a>
                                                <a href="tel:1-500-369-2580" class="theme-btn call-btn"><div class="btn-title">Or Call us 1-500-369-2580</div></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* <!-- Slide Item --> */}
                        <div class="slide-item">
                            <div class="image-layer" style={{ backgroundImage: `url('assect/images/main-slider/2.jpg')` }}></div>
                            <div class="auto-container">
                                <div class="content-box">
                                    <div class="content">
                                        <div class="inner">
                                            <div class="sub-title">IT Solutions For Easy Integration</div>
                                            <h1><strong>Innovative and Productive</strong></h1>
                                            <div class="text">Building a relationship between IT companies & experts</div>
                                            <div class="links-box">
                                                <a href="about.html" class="theme-btn btn-style-one"><div class="btn-title">More Details</div></a>
                                                <a href="tel:1-500-369-2580" class="theme-btn call-btn"><div class="btn-title">Or Call us 1-500-369-2580</div></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* <!-- Slide Item --> */}
                        <div class="slide-item">
                            <div class="image-layer" style={{ backgroundImage: `url('assect/images/main-slider/3.jpg')` }}></div>
                            <div class="auto-container">
                                <div class="content-box">
                                    <div class="content">
                                        <div class="inner">
                                            <div class="sub-title">IT Solutions For Easy Integration</div>
                                            <h1><strong>Innovative and Productive</strong></h1>
                                            <div class="text">Building a relationship between IT companies & experts</div>
                                            <div class="links-box">
                                                <a href="about.html" class="theme-btn btn-style-one"><div class="btn-title">More Details</div></a>
                                                <a href="tel:1-500-369-2580" class="theme-btn call-btn"><div class="btn-title">Or Call us 1-500-369-2580</div></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </OwlCarousel>
                </section>
           
        </>
    )
}

export default Owldemo1