import React from 'react'

const CaseSingle = () => {
  return (
     <>
         {/* <!-- Inner Banner Section --> */}
    <section class="inner-banner alternate">
        <div class="image-layer" style={{backgroundImage: `url(images/background/banner-bg-2.jpg)`}}></div>
        <div class="auto-container">
            <div class="inner">
                <div class="title-box">
                    <h1>Case Studies</h1>
                    <div class="d-text">Building a relationship between IT Services</div>
                </div>
            </div>
        </div>
    </section>
    {/* <!--End Banner Section --> */}

	<section class="case-single-section">
        <div class="auto-container">
            <div class="case-inner">
                
                {/* <!--Case Images--> */}
                <div class="case-images">
                    <div class="row clearfix">
                        {/* <!--Image Column--> */}
                        <div class="image-column col-lg-8 col-md-8 col-sm-12">
                            <figure class="image">
                                <a href="assect/images/resource/case-image-6.jpg" class="lightbox-image"><img src="assect/images/resource/case-image-6.jpg" alt=""/></a>
                            </figure>
                        </div>
                        {/* <!--Image Column--> */}
                        <div class="image-column col-lg-4 col-md-4 col-sm-12">
                            <figure class="image">
                                <a href="assect/images/resource/case-image-7.jpg" class="lightbox-image"><img src="assect/images/resource/case-image-7.jpg" alt=""/></a>
                            </figure>
                        </div>
                    </div>
                </div>
                
                {/* <!--Cases Title--> */}
                <div class="cases-title">
                    <div class="row clearfix">
                        <div class="column col-lg-4 col-md-12 col-sm-12">
                            <h2>Data Machine <br/> Learning</h2>
                        </div>
                        <div class="column col-lg-8 col-md-12 col-sm-12">
                            <div class="row clearfix">
                                <div class="info-column col-lg-4 col-md-4 col-sm-12">
                                    <div class="inner">
                                        <h3>Date</h3>
                                        <div class="text">8 Dec 2019</div>
                                    </div>
                                </div>
                                <div class="info-column col-lg-4 col-md-4 col-sm-12">
                                    <div class="inner">
                                        <h3>Client Name</h3>
                                        <div class="text">Jhone Doe</div>
                                    </div>
                                </div>
                                <div class="info-column col-lg-4 col-md-4 col-sm-12">
                                    <div class="inner">
                                        <h3>Project Type</h3>
                                        <div class="text">Data Analysis</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* <!--End Cases Title--> */}
                
                <div class="bold-text">Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.</div>
                <div class="text">
                    <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.</p>
                    <p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple</p>
                </div>
                <div class="two-column clearfix">
                    <div class="row clearfix">
                        {/* <!--Content Column--> */}
                        <div class="content-column col-lg-5 col-md-12 col-sm-12">
                            <h3>SEO Result, Increase Visitors 65%</h3>
                            <p>Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway </p>
                            <p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple</p>
                        </div>
                        {/* <!--Image Column--> */}
                        <div class="image-column col-lg-7 col-md-12 col-sm-12">
                            <div class="row clearfix">
                                <div class="column col-md-6 col-sm-12">
                                    <div class="image">
                                        <a href="assect/images/resource/case-image-8.jpg" class="lightbox-image"><img src="assect/images/resource/case-image-8.jpg" alt=""/></a>
                                    </div>
                                </div>
                                <div class="column col-md-6 col-sm-12">
                                    <div class="image">
                                        <a href="assect/images/resource/case-image-9.jpg" class="lightbox-image"><img src="assect/images/resource/case-image-9.jpg" alt=""/></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="contact-info-section" style={{backgroundImage:`url(assect/images/background/pattern-2.png)`}}>
        <div class="auto-container">
            <h3>Any Queries? Don’t Hesitate? Feel Free to Make a Call</h3>
            <div class="info-blocks">
                <div class="row clearfix">
                    {/* <!--Info Block--> */}
                    <div class="info-block col-md-6 col-sm-6 col-xs-12">
                        <div class="inner">
                            <div class="icon-box">
                                <span class="icon fa fa-envelope"></span>
                            </div>
                            <div class="text"><a href="mailto:support@zentec.com">support@zentec.com</a></div>
                        </div>
                    </div>
                    
                    {/* <!--Info Block--> */}
                    <div class="info-block col-md-6 col-sm-6 col-xs-12">
                        <div class="inner">
                            <div class="icon-box">
                                <span class="icon fa fa-phone-alt"></span>
                            </div>
                            <div class="text"><a href="tel:(+1)-500.369.2580">(+1) 500.369.2580</a></div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
     
     </>
  )
}

export default CaseSingle