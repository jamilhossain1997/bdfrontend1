import React from 'react';
import { Link } from 'react-router-dom';
import Owlcarousel2 from './Owlcarousel/Owlcarousel2';
import CountUp from 'react-countup';

const About = () => {
  return (
   <>
      {/* <!-- Inner Banner Section --> */}
    <section class="inner-banner">
        <div class="banner-curve"></div>
		<div class="auto-container">
            <div class="inner">
                <div class="theme-icon"></div>
    			<div class="title-box">
                    <h1>About Us</h1>
                    <div class="d-text">Building a relationship between IT Services</div>
                </div>
            </div>
		</div>
    </section>
    {/* <!--End Banner Section --> */}


    {/* <!--About Section--> */}
    <section class="about-section-three">
        <div class="auto-container">
            <div class="sec-title centered">
                <div class="upper-text">ZenTec - Welcome to IT Solutions</div>
                <h2><strong>Your next Preferred IT Partner</strong></h2>
            </div>

            <div class="upper-row">
            	<div class="row clearfix">
                    {/* <!--Text Column--> */}
                    <div class="text-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="text">
                                <p>Dolor sit amet, consectetur adipisicing elitm sed don eiusmod tempor sed incididunt ut labore etsu dolore magna aliquatenim minim veniam quis ipsum nostrud exerpsum citation ullamco laboris nisi ut aliquip consequat. </p>

                                <p>Duis aute irure dolorn reprehenderit voluptate velit esse dolore magna aliqua. Ut asto enim ad minim veniam quis nostrud exercitation ullamco.</p>
                            </div>
                        </div>
                    </div>
                    {/* <!--Text Column--> */}
                    <div class="text-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="text">
                                <ul class="list-style-one">
                                    <li>We are committed to providing quality IT Services</li>
                                    <li>Our benefits are endless for local IT Companies & Startups</li>
                                    <li>Really know the true needs and expectations of customers</li>
                                    <li>Talented & experienced management solutions for IT</li>
                                    <li>Processes of achieving the excellence and continue improvements</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="lower-row">
                <div class="row clearfix">
                    {/* <!--Featured Block--> */}
                    <div class="featured-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="image-box">
                                <Link to="/allService"><img src="assect/images/resource/featured-image-4.jpg" alt="" title=""/></Link>
                            </div>
                            <div class="lower-box">
                                <h3><Link to="/allService">Easier To Implement</Link></h3>
                                <div class="text">Sed incididunt labore dolore magna sed aliq veniam quis ipsu nostrud exercitation ullamco sed ipsum venum.</div>
                                <div class="more-link"><Link to="/allService"><span class="fa fa-arrow-right"></span></Link></div>
                            </div>
                        </div>
                    </div>
                    {/* <!--Featured Block--> */}
                    <div class="featured-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="image-box">
                                <Link to="/allService"><img src="assect/images/resource/featured-image-5.jpg" alt="" title=""/></Link>
                            </div>
                            <div class="lower-box">
                                <h3><Link to="/allService">Increase Growth Rates</Link></h3>
                                <div class="text">Sed incididunt labore dolore magna sed aliq veniam quis ipsu nostrud exercitation ullamco sed ipsum venum.</div>
                                <div class="more-link"><Link to="/allService"><span class="fa fa-arrow-right"></span></Link></div>
                            </div>
                        </div>
                    </div>
                    {/* <!--Featured Block--> */}
                    <div class="featured-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="image-box">
                                <Link to="/about"><img src="assect/images/resource/featured-image-6.jpg" alt="" title=""/></Link>
                            </div>
                            <div class="lower-box">
                                <h3><a Link to="/about">Branding Of Future</a></h3>
                                <div class="text">Sed incididunt labore dolore magna sed aliq veniam quis ipsu nostrud exercitation ullamco sed ipsum venum.</div>
                                <div class="more-link">< Link to="/about"><span class="fa fa-arrow-right"></span></Link></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>

    {/* <!--Locations Section--> */}
    <section class="locations-section">
        <div class="auto-container">
            <div class="sec-title centered">
                <div class="upper-text">ZenTec IT Services</div>
                <h2>Trusted By 5M ZenTec IT Customers Around The World</h2>
                <div class="lower-text">Sit amet consectetur adipisicing elitm sed eiusmod temp sed incididunt labore dolore magna aliquatenim veniam quis ipsum nostrud exer citation ullamco laboris.</div>
            </div>
            <div class="map-box">
                {/* <!--Map Image--> */}
                <div class="map-image">
                    <img src="assect/images/icons/map-pattern.png" alt="" title=""/>
                </div>

                {/* <!--Location Point--> */}
                <div class="location-point loc-one">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-two">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-three">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-four">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-five">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-six">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-seven">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-eight">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-nine">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-ten">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-eleven">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>
                {/* <!--Location Point--> */}
                <div class="location-point loc-twelve">
                    <div class="inner">100+ Projects Done For Local IT Companies</div>
                </div>

            </div>
        </div>
    </section>

    {/* <!--Default Background Section--> */}
    <section class="default-bg-section">
        <div class="image-layer" style={{backgroundImage: `url(assect/images/background/image-1.jpg)`}}></div>

        <div class="auto-container">
            <div class="content-box">
                <h2>Our IT Solutions will get you on move towards your destination faster than rivals in a more reliably way!</h2>
                <div class="link-box">
                    <Link to="/about" class="theme-btn btn-style-one"><div class="btn-title">Proven IT Solutions</div></Link>
                </div>
            </div>
        </div>
    </section>

    {/* <!--Fun Facts Section--> */}
    <section class="fun-facts-section">

        <div class="auto-container">
            <div class="fact-counter">

                <div class="row clearfix">
                    {/* <!--Column--> */}
                    <div class="counter-column col-lg-4 col-md-4 col-sm-12">
                        <div class="inner wow fadeInUp" data-wow-delay="0ms">
                            <div class="upper-title">System Integrations Done</div>
                            <div class="count-box">
                            <CountUp class="count-text" end={1458} >
                                 0   
                            </CountUp>
                               </div>
                            <div class="counter-title">for customers</div>
                        </div>
                    </div>

                    {/* <!--Column--> */}
                    <div class="counter-column col-lg-4 col-md-4 col-sm-12 wow fadeInUp">
                        <div class="inner wow fadeInUp" data-wow-delay="300ms">
                            <div class="upper-title">Powerful Team to Focus</div>
                            <div class="count-box"> <CountUp class="count-text" end={160} >
                                 0   
                            </CountUp>+</div>
                            <div class="counter-title">Expert Members</div>
                        </div>
                    </div>

                    {/* <!--Column--> */}
                    <div class="counter-column col-lg-4 col-md-4 col-sm-12 wow fadeInUp">
                        <div class="inner wow fadeInUp" data-wow-delay="600ms">
                            <div class="upper-title">Launched Case Studies</div>
                            <div class="count-box"> <CountUp class="count-text" end={1080} >
                                 0   
                            </CountUp></div>
                            <div class="counter-title">Fully Launched</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    {/* <!--Team Section--> */}
    <section class="team-section">
        <div class="pattern-layer"></div>

        <div class="auto-container">
            <div class="row clearfix">
                {/* <!--Column--> */}
                <div class="column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title">
                            <div class="upper-text">Ambitious & Dedicated Team</div>
                            <h2>ZenTech <strong>IT Experts</strong></h2>
                        </div>
                        <div class="text-content">
                            <div class="text">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet velit sed quia non numquam eius modi tempora incidunt labore dolore magna aliqua enim minim veniam, quis nostrud exercitation ullamco.</div>
                        </div>

                        <div class="team-block wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <Link to="/about"><img src="assect/images/resource/team-image-1.jpg" alt=""/></Link>
                                </div>
                                <div class="title-box">
                                    <h3 class="name"><Link to="/about">Benjamin Zara</Link></h3>
                                    <div class="designation">Marketing Manager</div>
                                </div>
                                <div class="text">Veniam quis nostrud exercitaon ullam laboris nis aliquip sed conseqal.</div>
                            </div>
                        </div>

                    </div>
                </div>

                {/* <!--Column--> */}
                <div class="column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">

                        <div class="team-block wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <Link to="/about"><img src="assect/images/resource/team-image-2.jpg" alt=""/></Link>
                                </div>
                                <div class="title-box">
                                    <h3 class="name"><Link to="/about">Amayda Tim</Link></h3>
                                    <div class="designation">Team Leader, IT</div>
                                </div>
                                <div class="text">Veniam quis nostrud exercitaon ullam laboris nis aliquip sed conseqal.</div>
                            </div>
                        </div>

                        <div class="team-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <Link to="/about"><img src="assect/images/resource/team-image-3.jpg" alt=""/></Link>
                                </div>
                                <div class="title-box">
                                    <h3 class="name"><Link to='/about'>Paul Wilsona</Link></h3>
                                    <div class="designation">CEO, IT Expert</div>
                                </div>
                                <div class="text">Veniam quis nostrud exercitaon ullam laboris nis aliquip sed conseqal.</div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

            <div class="view-all link-box">
                <Link to="/about" class="theme-btn btn-style-one"><div class="btn-title">View Full Team</div></Link>
            </div>

        </div>
    </section>

    {/* <!--Sponsors Section--> */}
    <Owlcarousel2/>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>
   </>
  )
}

export default About