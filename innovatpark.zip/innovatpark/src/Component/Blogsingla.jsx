import React,{useState,useEffect}from 'react';
import axios from 'axios';
import {useHistory} from 'react-router-dom';

const Blogsingla = () => {

    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [comment,setComment]=useState('');
    const [data,setData]=useState([]);
    const histroy=useHistory();
   
   useEffect(()=>{
         axios.get('/api/ClientCommentView')
         .then(function (response) {
            console.log(response);
            setData(response.data);
          })
          .catch(function (error) {
            console.log(error);
          })
   },[])
    function handleClick(){
        let item={name,email,comment}
        axios.post('/api/ClientComment',item)
        .then(function (response) {
         console.log(response);
         histroy.push('/blogsingle');
        
       })
       .catch(function (error) {
         console.log(error);
       })
     }
  return (
    <>
         {/* <!-- Inner Banner Section --> */}
    <section class="inner-banner">
        <div class="banner-curve"></div>
		<div class="auto-container">
            <div class="inner">
                <div class="theme-icon"></div>
    			<div class="title-box">
                    <h1>Full Blog Post</h1>
                    <div class="d-text">Building a relationship between IT Services</div>
                </div>
            </div>
		</div>
    </section>
    {/* <!--End Banner Section --> */}

	<div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">
                
                {/* <!--Content Side--> */}
                <div class="content-side col-lg-9 col-md-12 col-sm-12">
                    <div class="blog-content">
                        
                        <div class="post-details">
                            {/* <!--News Block--> */}
                            <div class="news-block-three">
                                <div class="inner-box">
                                    <div class="image-box">
                                        <img src="assect/images/resource/blog-image-14.jpg" alt="" title=""/>
                                    </div>
                                    <div class="lower-box">
                                        <div class="category">IT Projects, Development</div>
                                        <h3>Efficient & Measurable Benefits of Software</h3>
                                        <div class="meta-info">
                                            <ul class="clearfix">
                                                <li><a href="#">By Admin</a></li>
                                                <li><a href="#">24 June 2019</a></li>
                                                <li><a href="#">Comments: 53</a></li>
                                            </ul>
                                        </div>

                                        <div class="text">
                                            <p>Dolor sit amet, consectetur adipisicing elitm sed don eiusmod tempor sed incididunt ut labore etsu dolore magna aliqua tenim minim veniam quis ipsum nostrud exerpsum citation ullamco laboris nisiut aliquip consequat. Duis aute irure dolorn reprehenderit voluptate velit. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>

                                            <blockquote>
                                                We are committed to providing quality IT Services our benefits are endless for local IT Companies & Startups, really know the true needs and expectations of customers, talented & experienced management solutions.
                                            </blockquote>

                                            <p>Exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus.</p>

                                            <div class="two-col row clearfix">
                                                <div class="image-column col-md-6 col-sm-12">
                                                    <div class="image"><img src="assect/images/resource/blog-image-15.jpg" alt=""/></div>
                                                </div>

                                                <div class="image-column col-md-6 col-sm-12">
                                                    <div class="image"><img src="assect/images/resource/blog-image-16.jpg" alt=""/></div>
                                                </div>
                                            </div>

                                            <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa lorem ipsum dolor sit amet, con velit esse cillum dolore eu fugiat nulla pariatur totam rem aperiam.</p>

                                        </div>
                                    </div>

                                    <div class="lower-row clearfix">
                                        <div class="tags">
                                            <span class="icon sl-icon-tag"></span>
                                            <a href="#">CaseStudies</a>, <a href="#">Business</a>, <a href="#">IT Services</a>
                                        </div>

                                        <div class="share-it">
                                            <a href="#" class="share-toggler"><span class="icon sl-icon-share"></span> Share This</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* <div class="author-box">
                                <div class="inner-box">
                                    <figure class="thumb"><img src="assect/images/resource/author-thumb-4.jpg" alt=""/></figure>
                                    <h3 class="name">Mark Hamburg</h3>
                                    <div class="text">Eiusmod tem sed incididunt labore dolore magna sed aliquatenim minim veniam quis ipsum nostrud exercitation ullamco nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate.</div>
                                    <div class="social-links">
                                        <ul class="clearfix">
                                            <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                            <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                            <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                            <li><a href="#"><span class="fab fa-youtube"></span></a></li>
                                            <li><a href="#"><span class="fab fa-pinterest"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div> */}

                            {/* <!--Comments Area--> */}
                            <div class="comments-area">
                                <div class="comments-title">
                                    <h2>Comments</h2>
                                </div>
                                {
                                    data.map((items)=>
                                        <div class="comment-box">
                                            <div class="comment"> 
                                                <div class="info">
                                                    <div class="name">{items.name}</div>
                                                    <div class="reply-btn"><a href="#"><span class="fa fa-reply"></span> Reply</a></div>
                                                </div>
                                                <div class="text">{items.comment}</div>
        
                                            </div>
                                    </div>
                                    )
                                }
                                

                              

                            </div>

                            {/* <!--Leave Comment Form--> */}
                            <div class="leave-comments">
                                <div class="comments-title">
                                    <h2>Leave A Reply</h2>
                                    <div class="instruction">Your email address will not be published. Required fields are marked *</div>
                                </div>
                                <div class="default-form comment-form">
                                    <div class="row clearfix">                                    
                                       <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="text"  value={name} onChange={(e) => setName(e.target.value)} placeholder="Your Name" required/>
                                        </div>
                                        
                                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                            <input type="email"  value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required/>
                                        </div>

                                       

                                        

                                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                            <textarea  value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Message" required></textarea>
                                        </div>
                
                                        <div class="form-group col-md-12 col-sm-12">
                                            <button type="submit" onClick={handleClick} class="theme-btn btn-style-one"><span class="btn-title">Make a Request</span></button>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                {/* <!--Sidebar Side--> */}
                <div class="sidebar-side col-lg-3 col-md-12 col-sm-12">
                    <aside class="sidebar blog-sidebar">
                        {/* <!--Sidebar Widget--> */}
                        <div class="sidebar-widget search-box">
                            <form method="post" action="https://t.commonsupport.xyz/zentec/blog.html">
                                <div class="form-group">
                                    <input type="search" name="search-field" value="" placeholder="Search.." required=""/>
                                    <button type="submit"><span class="icon fa fa-search"></span></button>
                                </div>
                            </form>

                        </div>
                        <div class="sidebar-widget archives">
                            <div class="widget-inner">
                                <div class="sidebar-title">
                                    <h3>Categories</h3>
                                </div>

                                <ul>
                                    <li><a href="#">Business</a></li>
                                    <li class="active"><a href="#">IT Solutions</a></li>
                                    <li><a href="#">IT Development</a></li>
                                    <li><a href="#">Data Security</a></li>
                                    <li><a href="#">Startup Professionals</a></li>
                                    <li><a href="#">Digital Marketing</a></li>
                                    <li><a href="#">Strategies</a></li>
                                </ul>
                            </div>
                        </div>
                        
                        <div class="sidebar-widget recent-posts">
                            <div class="widget-inner">
                                <div class="sidebar-title">
                                    <h3>Recent Posts</h3>
                                </div>

                                <div class="post">
                                    <figure class="post-thumb"><img src="assect/images/resource/post-thumb-1.jpg" alt=""/></figure>
                                    <h3 class="text"><a href="#">Commercial Apps Multi Platform and Device</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="post">
                                    <figure class="post-thumb"><img src="assect/images/resource/post-thumb-2.jpg" alt=""/></figure>
                                    <h3 class="text"><a href="#">Leverage the Spectrum of Technologies</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="post">
                                    <figure class="post-thumb"><img src="assect/images/resource/post-thumb-3.jpg" alt=""/></figure>
                                    <h3 class="text"><a href="#">Efficient & Mesaurable Benefits of Software</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="sidebar-widget popular-tags">
                            <div class="widget-inner">
                                <div class="sidebar-title">
                                    <h3>Popular Tags</h3>
                                    
                                </div>
                                <ul class="tags-list clearfix">
                                    <li><a href="#">IT Solutions</a></li>
                                    <li><a href="#">Business</a></li>
                                    <li><a href="#">Security</a></li>
                                    <li><a href="#">Power & Energy</a></li>
                                    <li><a href="#">IT Services</a></li>
                                    <li><a href="#">Digital</a></li>
                                    <li><a href="#">Software</a></li>
                                    <li><a href="#">Marketing</a></li>
                                </ul>
                            </div>
                        </div>
                    </aside>
                </div>
                
            </div>
        </div>
    </div>

    {/* <!--Separator--> */}
    <div class="theme-separator"></div>

    </>
  )
}

export default Blogsingla