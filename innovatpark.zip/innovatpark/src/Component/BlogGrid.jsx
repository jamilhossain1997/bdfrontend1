import React from 'react'

const BlogGrid = () => {
    return (
        <>
            {/* <!-- Inner Banner Section --> */}
            <section class="inner-banner">
                <div class="banner-curve"></div>
                <div class="auto-container">
                    <div class="inner">
                        <div class="theme-icon"></div>
                        <div class="title-box">
                            <h1>IT News</h1>
                            <div class="d-text">Building a relationship between IT Services</div>
                        </div>
                    </div>
                </div>
            </section>
            {/* <!--End Banner Section --> */}

            {/* <!--News Section--> */}
            <section class="news-section blog-grid">
                <div class="auto-container">
                    <div class="row clearfix">
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-1.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">IT Projects</div>
                                    <h3><a href="blog-single.html">10 Efficient & Measurable Benefits of Software</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-2.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">Mobile Apps</div>
                                    <h3><a href="blog-single.html">Native or Cross-Platform: Mobile Development</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-3.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">Development</div>
                                    <h3><a href="blog-single.html">Vital Tips For Blockchain Software Product</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-4.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">Security News</div>
                                    <h3><a href="blog-single.html">Data Security with multiple business values</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-5.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">IT Sector News</div>
                                    <h3><a href="blog-single.html">Leverage the full spectrum of technology stacks</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-6.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">Development</div>
                                    <h3><a href="blog-single.html">Commercial apps multi- platform and multi-device</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-7.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">IT Projects</div>
                                    <h3><a href="blog-single.html">10 Efficient & Measurable Benefits of Software</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-8.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">Mobile Apps</div>
                                    <h3><a href="blog-single.html">Native or Cross-Platform: Mobile Development</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                        {/* <!--News Block--> */}
                        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <a href="blog-single.html"><img src="assect/images/resource/blog-image-9.jpg" alt="" title="" /></a>
                                </div>
                                <div class="lower-box">
                                    <div class="category">Development</div>
                                    <h3><a href="blog-single.html">Vital Tips For Blockchain Software Product</a></h3>
                                    <div class="meta-info">
                                        <ul class="clearfix">
                                            <li><a href="#">By Admin</a></li>
                                            <li><a href="#">24 June 2019</a></li>
                                        </ul>
                                    </div>
                                    <div class="more-link"><a href="blog-single.html"><span class="fa fa-arrow-right"></span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="load-more link-box">
                        <a href="blog-fullwidth.html" class="theme-btn btn-style-two"><div class="btn-title">Load More News</div></a>
                    </div>

                </div>
            </section>
            <div class="theme-separator"></div>
        </>
    )
}

export default BlogGrid