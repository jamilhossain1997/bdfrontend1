import React from 'react';
import { useEffect,useState } from 'react';
import { Link } from 'react-router-dom';

const StickyHeader = () => {
    const [isVisible, setIsVisible] = useState();
    const [height, setHeight] = useState(0)
    // Sticky Menu Area
    useEffect(() => {
        window.addEventListener('scroll', isSticky);
        return () => {
            window.removeEventListener('scroll', isSticky);
        };
    });
    /* Method that will fix header after a specific scrollable */
    const isSticky = (e) => {
        const header = document.querySelector('.header-section');
        const scrollTop = window.scrollY;
        scrollTop >= 200 ? header.classList.add('sticky-header') : header.classList.remove('sticky-header');
    };
   
    useEffect(() => {  
        setIsVisible(false);
        window.addEventListener("scroll", listenToScroll);
        return () => 
           window.removeEventListener("scroll", listenToScroll); 
      }, [])

      const listenToScroll = () => {
        let heightToHideFrom = 200;
        const winScroll = document.body.scrollTop || 
            document.documentElement.scrollTop;
        setHeight(winScroll);
    
        if (winScroll > heightToHideFrom) {  
             isVisible && setIsVisible(false);
        } else {
             setIsVisible(true);
        }  
      };
    return (
        <>
         {
           isVisible  &&
           <header className="header-section d-none d-xl-block">
                <div class="auto-container clearfix">
                    {/* <!--Logo--> */}
                    <div class="logo pull-left">
                        <a href="#" title="iNNOVAT PARK -Technology for innovators">
                            <img class="w-50" src="assect/assets/images/logo.png" alt="iNNOVAT PARK" title="iNNOVAT PARK -Technology for innovators" />
                        </a>
                    </div>
                    {/* <!--Right Col--> */}
                    <div class="pull-right">
                        {/* <!-- Main Menu --> */}
                        <nav class="main-menu navbar-expand-md navbar-light">
                                        <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                          
                                            <ul class="navigation clearfix">
                                                <li><Link to='/' >Home</Link> </li>
                                                <li class="dropdown"><Link to='/about'>About Us</Link>
                                                    <ul>
                                                        <li><Link to='/about'>About Us</Link></li>
                                                        <li><Link to='/casestudie'>Case Studies</Link></li>
                                                        <li><Link to='/faq'>FAQ's</Link></li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown"><Link to='/allService'>IT Solutions</Link>
                                                    <ul>
                                                        <li><Link to='/allService'>All Services</Link></li>
                                                        <li><Link to='/dataInfrastructure'>Data Infrastructure</Link></li>
                                                        <li><Link to="/CloudIntegration">IT Cloud Integration</Link></li>
                                                        {/* <li><a href="it-startup.html">IT Startup Projects</a></li>
                                                        <li><a href="product-engineering.html">Product Engineering</a></li>
                                                        <li><a href="business-security.html">Business Security</a></li> */}
                                                    </ul>
                                                </li>
                                                <li class="dropdown"><a href="case-studies.html">Case Studies</a>
                                                    <ul>
                                                        <li><Link to='/casestudie'>Case Studies</Link></li>
                                                        <li><Link to='/CaseSingle'>Project Details</Link></li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown"><a href="blog-grid.html">News</a>
                                                    <ul>
                                                        <li><Link to='/blog'>Blog Grid Style</Link></li>
                                                        <li><Link to="/blogfullwidth">Blog Fullwidth</Link></li>
                                                        <li><Link to="/blogsingle">Blog Post Details</Link></li>
                                                    </ul>
                                                </li>
                                                <li><Link to='/contact'>Contact</Link></li>
                                            </ul>
                                            
                                        </div>
                                    </nav>
                        {/* <!-- Main Menu End--> */}
                    </div>
                </div>
            </header>
        }
        </>
    )
}

export default StickyHeader