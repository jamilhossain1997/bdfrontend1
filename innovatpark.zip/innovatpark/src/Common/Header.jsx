import React from 'react';
import { Link } from 'react-router-dom';
// import StickyHeader from 'react-sticky-header';
import StickyHeader from './StickyHeader';
import Nav from './Nav';


const Header = () => {
 
    return (
        <>
            
                {/* <!-- Preloader --> */}
                {/* <div class="preloader">
                    <div class="icon"></div>
                </div> */}

                {/* <!-- Main Header --> */}
                <header class="main-header header-style-two">

                    {/* <!-- Header Upper --> */}
                    <div class="header-upper">
                        <div class="auto-container">
                            <div class="inner-container clearfix">
                                {/* <!--Logo--> */}
                                <div class="logo-box">
                                    <div class="logo">
                                        <Link to='/' title="iNNOVAT PARK -Technology for innovators">
                                            <img src="assect/assets/images/logo.png" alt="iNNOVAT PARK" title="iNNOVAT PARK -Technology for innovators" />
                                        </Link>
                                    </div>
                                </div>
                                <div class="right-info clearfix">
                                    {/* <!--Info--> */}
                                    <div class="info clearfix">
                                        {/* <!--Info Block--> */}
                                        <div class="info-block">
                                            <div class="icon-box">
                                                <span class="flaticon-placeholder-2"></span>
                                            </div>
                                            <div class="info-text">
                                                <span>House #252/7, Road No #06,</span>
                                                <strong>Mohammdia Housing Ltd. Dhaka</strong>
                                            </div>
                                        </div>
                                        {/* <!--Info Block--> */}
                                        <div class="info-block">
                                            <div class="icon-box">
                                                <span class="flaticon-smartphone"></span>
                                            </div>
                                            <div class="info-text">
                                                <span>Call Us Now</span>
                                                <a href="tel:+88 01771-858483"><strong>+88 01771-858483</strong></a>
                                            </div>
                                        </div>
                                        {/* <!--Info Block--> */}
                                        <div class="info-block">
                                            <div class="icon-box">
                                                <span class="flaticon-email"></span>
                                            </div>
                                            <div class="info-text">
                                                <span>Send Us Email</span>
                                                <a href="mailto:support@innovatpark.com"><strong>support@innovatpark.com</strong></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!--End Header Upper--> */}

                   <div class="header-lower">
                      
                         <Nav />
                         <div class="auto-container">
                            <div class="nav-box clearfix">
                                <div class="nav-outer clearfix">
                                    {/* <!--Mobile Navigation Toggler--> */}
                                    {/* <div class="mobile-nav-toggler"><span class="icon flaticon-menu-1"></span></div> */}

                                    {/* <!-- Main Menu --> */}
                                    <nav class="main-menu navbar-expand-md navbar-light">
                                        <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                          
                                            <ul class="navigation clearfix">
                                                <li><Link to='/' >Home</Link> </li>
                                                <li class="dropdown"><Link to='/about'>About Us</Link>
                                                    <ul>
                                                        <li><Link to='/about'>About Us</Link></li>
                                                        <li><Link to='/casestudie'>Case Studies</Link></li>
                                                        <li><Link to='/faq'>FAQ's</Link></li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown"><Link to='/allService'>IT Solutions</Link>
                                                    <ul>
                                                        <li><Link to='/allService'>All Services</Link></li>
                                                        <li><Link to='/dataInfrastructure'>Data Infrastructure</Link></li>
                                                        <li><Link to="/CloudIntegration">IT Cloud Integration</Link></li>
                                                        {/* <li><a href="it-startup.html">IT Startup Projects</a></li>
                                                        <li><a href="product-engineering.html">Product Engineering</a></li>
                                                        <li><a href="business-security.html">Business Security</a></li> */}
                                                    </ul>
                                                </li>
                                                <li class="dropdown"><a href="case-studies.html">Case Studies</a>
                                                    <ul>
                                                        <li><Link to='/casestudie'>Case Studies</Link></li>
                                                        <li><Link to='/CaseSingle'>Project Details</Link></li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown"><a href="blog-grid.html">News</a>
                                                    <ul>
                                                        <li><Link to='/blog'>Blog Grid Style</Link></li>
                                                        <li><Link to="/blogfullwidth">Blog Fullwidth</Link></li>
                                                        <li><Link to="/blogsingle">Blog Post Details</Link></li>
                                                    </ul>
                                                </li>
                                                <li><Link to='/contact'>Contact</Link></li>
                                            </ul>
                                            
                                        </div>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* <!-- Sticky Header  --> */} 
                        <StickyHeader/>
                    {/* <!-- End Sticky Menu --> */}

                    {/* <!-- Mobile Menu  --> */}
                
                    {/* <!-- End Mobile Menu --> */}
                </header>
                {/* <!-- End Main Header --> */}
           
        </>
    )
}

export default Header