import React from 'react';
import { Navbar, Nav, NavDropdown, Container } from 'react-bootstrap';
import {Link} from 'react-router-dom';

const Navbarmenu = () => {
  return (
    <>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container>
         
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
            {/* <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand> */}
              <Nav.Link><Link to='/' style={{color:`#938369`}}>Home</Link></Nav.Link>
              <NavDropdown title="About Us" id="collasible-nav-dropdown">
                <NavDropdown.Item><Link to='/about'>About Us</Link></NavDropdown.Item>
                <NavDropdown.Item><Link to='/casestudie'>Case Studies</Link></NavDropdown.Item>
                <NavDropdown.Item><Link to='/faq'>FAQ's</Link></NavDropdown.Item>
              </NavDropdown>
              <NavDropdown title="IT Solutions" id="collasible-nav-dropdown">
                <NavDropdown.Item><Link to='/allService'>All Services</Link></NavDropdown.Item>
                <NavDropdown.Item><Link to='/dataInfrastructure'>Data Infrastructure</Link></NavDropdown.Item>
                <NavDropdown.Item><Link to='/CloudIntegration'>IT Cloud Integration</Link></NavDropdown.Item>
              </NavDropdown>
              <NavDropdown title="Case Studies" id="collasible-nav-dropdown">
                <NavDropdown.Item><Link to='/about'>Case Studies</Link></NavDropdown.Item>
                <NavDropdown.Item><Link to='/CaseSingle'>Project Details</Link></NavDropdown.Item>
              </NavDropdown>
              <NavDropdown title="News" id="collasible-nav-dropdown">
                <NavDropdown.Item><Link to='/blog'>Blog Grid Style</Link></NavDropdown.Item>
                <NavDropdown.Item><Link to='/blogfullwidth'>Blog Fullwidth</Link></NavDropdown.Item>
                <NavDropdown.Item><Link to='/blogsingle'>Blog Post Details</Link></NavDropdown.Item>
              </NavDropdown>
              <Nav.Link><Link to='/contact'  style={{color:`#938369`}}>Contact</Link></Nav.Link>
            </Nav>
            {/* <Nav>
              <Nav.Link href="#deets">More deets</Nav.Link>
              <Nav.Link eventKey={2} href="#memes">
                Dank memes
              </Nav.Link>
            </Nav> */}
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  )
}

export default Navbarmenu