import React from 'react';
import Link from 'next/link';

const Header = () => {
    return (
        <>
            <nav className="navbar navbar-light bg-dark">
                <div className="container-fluid">
                    <span className="navbar-brand mb-0 h1 text-white"><Link href={"/"}>Navbar</Link></span>
                </div>
            </nav>
        </>
    )
}

export default Header